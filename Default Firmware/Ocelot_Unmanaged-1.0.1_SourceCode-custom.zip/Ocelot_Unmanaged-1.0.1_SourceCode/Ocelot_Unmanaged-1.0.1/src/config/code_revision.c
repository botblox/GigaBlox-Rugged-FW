const char code *CODE_REVISION = "a8a9714";
